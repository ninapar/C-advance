﻿/*Create a class called Animal with the following properties and methods:
Properties:
Name (string)
Age (int)
Methods:
MakeSound() (returns a string representing the sound the animal makes)
Create two derived classes Dog and Cat that inherit from the Animal class. Override the MakeSound() method in both derived classes to return appropriate sounds for each animal (e.g., "Woof" for Dog and "Meow" for Cat).
Create an interface called IMove with a method called Move() that returns a string representing the type of movement (e.g., "walk", "run", "fly").
Implement the IMove interface in both Dog and Cat classes. In the Move() method for each class, return a string representing how each animal moves (e.g., "Dog walks" for Dog and "Cat runs" for Cat).
In the Main method of your program, create instances of Dog and Cat, set their Name and Age properties, and display their information using the following format: "{Name} is {Age} years old, makes a {Sound} sound, and {Movement}."


Example output:

Rex is 5 years old, makes a Woof sound, and Dog walks. 

Whiskers is 3 years old, makes a Meow sound, and Cat runs.*/


using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Oops
{
    public class Animal
    {
        public string Name  { get; set; }
        public int Age { get; set; }
        public virtual string MakeSound()
        {
            return "Animal makes sound.";
        }
    }
}
