﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Oops
{
    public class Cat :Animal, IMove
    {
        public override string MakeSound()
        {
            return "Meow";
        }
        public string Move()
        {
            return " Cat runs";
        }

    }
}
