﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Oops
{
    public class Dog : Animal, IMove
    {
        public override string MakeSound()
        {
            return "Woof";
        }

        public string Move()
        {
            return "Dog walks";
        }
    }
}
