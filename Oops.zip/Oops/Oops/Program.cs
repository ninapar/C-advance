﻿using Oops;
using System.Security.Cryptography;

class Program
{
    static void Main(string[] args)
    {
        {
            Dog dog = new Dog();
            dog.Name = "Goofy";
            dog.Age = 6;

            Cat cat = new Cat();
            cat.Name = "Garfield";
            cat.Age = 4;


            Console.WriteLine($"{dog.Name} is {dog.Age} years old, makes a {dog.MakeSound()} sound, and {dog.Move()}.");
            Console.WriteLine($"{cat.Name} is {cat.Age} years old, makes a {cat.MakeSound()} sound, and {cat.Move()}.");
        }

    }
}

