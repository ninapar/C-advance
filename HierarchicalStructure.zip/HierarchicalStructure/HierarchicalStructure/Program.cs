﻿
class Program
{
    static void Main()
    {
        Family family = new Family();

        Person person1 = new Person("Ed", 40);
        Person person2 = new Person("May", 35);
        Person person3 = new Person("Aaron", 10);
        Person person4 = new Person("Selena", 8);
        Person person5 = new Person("Ali", 70);
        Person person6 = new Person("Suri", 68);
        Person person7 = new Person("Omid", 65);
        Person person8 = new Person("Eli", 60);


        person1.Parents.Add(person5);
        person1.Parents.Add(person6);
        person2.Parents.Add(person7);
        person2.Parents.Add(person8);
        person3.Parents.Add(person1);
        person3.Parents.Add(person2);
        person4.Parents.Add(person1);
        person4.Parents.Add(person2);

        family.AddMember(person1);
        family.AddMember(person2);
        family.AddMember(person3);
        family.AddMember(person4);
        family.AddMember(person5);
        family.AddMember(person6);
        family.AddMember(person7);
        family.AddMember(person8);

        foreach (var person in family)
        {
            person.DisplayInfo();
            Console.WriteLine();
        }

    }
}