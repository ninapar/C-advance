﻿/*Create a new C# Console Application project.
Define a simple "Person" class with the following properties:
Name (string)
Age (int)
Parent (Person)
The Parent property represents a self-referential relationship in the Person class.
Implement a method "DisplayInfo()" in the Person class that prints the person's Name, Age, and Parent's Name (if available).
Create a "Family" class that represents a collection of Person objects. Use a List<Person> to store the collection internally.
Implement the IEnumerable interface in the Family class, providing the necessary GetEnumerator() method for iterating over the collection.
Add a method "AddMember(Person person)" to the Family class that allows adding a new person to the family.
In the Main() method of your console application, create a new instance of the Family class and add a few Person objects to it, making sure to set their Parent properties where appropriate.
Use a foreach loop to iterate over the Family collection and call the DisplayInfo() method on each Person object.
Properly format the output to be readable and organized.
Test your program by running it and observing the output.*/

using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;

public class Person
{
    public string Name { get; set; }
    public int Age { get; set; }
    public List<Person> Parents { get; set; }

    public Person(string name, int age)
    {
        Name = name;
        Age = age;
        Parents = new List<Person>();
    }

    public void DisplayInfo()
    {
        Console.Write($"Name: {Name}, Age: {Age}, ");
        if (Parents.Any())
        {
            Console.Write("Parents's Name: ");
            for (int i = 0; i < Parents.Count; i++)
            {
                Console.Write(Parents[i].Name);
                if (i < Parents.Count - 1)
                {
                    Console.Write(", ");
                }
            }
        }
        else
        {
            Console.Write("No parent information available.");
        }
        Console.WriteLine(); 
    }
}
