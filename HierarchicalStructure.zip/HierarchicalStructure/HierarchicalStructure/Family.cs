﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

public class Family : IEnumerable<Person>
{
    private List<Person> members;

    // Constructor for Family class
    public Family()
    {
        members = new List<Person>();
    }

    public void AddMember(Person person)
    {
        members.Add(person);
    }

    public IEnumerator<Person> GetEnumerator()
    {
        return members.GetEnumerator();
    }

    IEnumerator IEnumerable.GetEnumerator()
    {
        return GetEnumerator();
    }
}
