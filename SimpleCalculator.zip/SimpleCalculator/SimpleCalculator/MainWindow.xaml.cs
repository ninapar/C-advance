﻿using System;
using System.Windows;

namespace SimpleCalculatorApp
{
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
        }

        private void Add_Click(object sender, RoutedEventArgs e)
        {
            CalculateResult('+');
        }

        private void Subtract_Click(object sender, RoutedEventArgs e)
        {
            CalculateResult('-');
        }

        private void Multiply_Click(object sender, RoutedEventArgs e)
        {
            CalculateResult('*');
        }

        private void Divide_Click(object sender, RoutedEventArgs e)
        {
            CalculateResult('/');
        }

        private void CalculateResult(char operation)
        {
            if (!int.TryParse(operand1.Text, out int operand1Value) || !int.TryParse(operand2.Text, out int operand2Value))
            {
                resultLabel.Content = "Invalid input";
                return;
            }

            if (operation == '/' && operand2Value == 0)
            {
                resultLabel.Content = "Division by zero";
                return;
            }

            int result = 0;
            switch (operation)
            {
                case '+':
                    result = operand1Value + operand2Value;
                    break;
                case '-':
                    result = operand1Value - operand2Value;
                    break;
                case '*':
                    result = operand1Value * operand2Value;
                    break;
                case '/':
                    result = operand1Value / operand2Value;
                    break;
            }

            resultLabel.Content = "Result: " + result.ToString();
        }
    }
}
