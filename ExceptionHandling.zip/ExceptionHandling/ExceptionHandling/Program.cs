﻿/*Objective:
Practice using basic exception-handling concepts in C# to handle potential runtime errors.

Requirements:
Create a new Console Application in C#.
Implement a program that calculates the division of two numbers the user enters.
Apply exception handling to catch potential runtime errors (e.g., dividing by zero, non-numeric input).
Display suitable error messages when exceptions are caught.
Ensure the program continues running and accepts new values after handling exceptions.
Evaluation Criteria for Basic Exception Handling Assignment:

Code Organization: Well-organized code, clear variable/method names, and appropriate comments.
Input Validation: Correctly validate input, display error messages, and request new input.
Exception Handling: Proper use of try-catch blocks, specific and generic exceptions caught.
Program Flow: Continuous execution until user exit, smooth input re-entry after exceptions.
Output: Correct results, appropriate error messages, and clear user-friendly presentation.*/


using System;

namespace ExceptionHandling
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Welcome to the Division Calculator");

            bool continueCalculating = true;

            while (continueCalculating)
            {
                try
                {
                    double number1, number2;

                    Console.Write("Please enter the first number: ");
                    if (!double.TryParse(Console.ReadLine(), out number1))
                    {
                        throw new FormatException("Please enter a valid number for the first number.");
                    }

                    Console.Write("Please enter the second number: ");
                    if (!double.TryParse(Console.ReadLine(), out number2))
                    {
                        throw new FormatException("Please enter a valid number for the second number.");
                    }

                    if (number2 == 0)
                    {
                        throw new DivideByZeroException("Cannot divide by zero.");
                    }

                    double result = number1 / number2;
                    Console.WriteLine($"Result: {number1} / {number2} = {result}");
                }
                catch (FormatException ex)
                {
                    Console.WriteLine(ex.Message);
                }
                catch (DivideByZeroException ex)
                {
                    Console.WriteLine(ex.Message);
                }
                catch (Exception ex)
                {
                    Console.WriteLine($"Error: {ex.Message}");
                }

                Console.WriteLine("Do you want to perform another division? (y/n)");
                string response;
                do
                {
                    response = Console.ReadLine() ?? ""; // Assign empty string if null
                    if (!string.IsNullOrEmpty(response))
                    {
                        response = response.ToLower();
                        if (response != "y" && response != "n")
                        {
                            Console.WriteLine("Invalid input. Please enter 'y' for yes or 'n' for no.");
                        }
                    }
                    else
                    {
                        Console.WriteLine("Error reading input. Please try again.");
                    }
                } while (response != "y" && response != "n");

                continueCalculating = response == "y";
            }

            Console.WriteLine("Thank you for using the Calculator");
            Console.ReadKey();
        }
    }
}
