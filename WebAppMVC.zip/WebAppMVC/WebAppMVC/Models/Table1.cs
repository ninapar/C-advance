﻿using System;
using System.Collections.Generic;

namespace WebAppMVC.Models;

public partial class Table1
{
    public int? Id { get; set; }

    public string? Type { get; set; }

    public DateTime? CreatedDate { get; set; }
}
