﻿using System;
using System.IO;
using System.Text;
using System.Text.Json;
using System.Threading.Tasks;


public class Program
{
    public static async Task Main()
    {
        string filePath = "temp.txt";
        string serializedFilePath = "person.json";

        // Synchronous file operations
        WriteToFile(filePath, "Hello, this is a sample text for synchronous file operations!");
        string content = ReadFromFile(filePath);
        Console.WriteLine("Synchronous File Content: " + content);
        File.Delete(filePath);
        Console.WriteLine("File deleted.");

        // Asynchronous file operations
        await WriteToFileAsync(filePath, "Hello, this is a sample text for asynchronous file operations!");
        content = await ReadFromFileAsync(filePath);
        Console.WriteLine("Asynchronous File Content: " + content);
        File.Delete(filePath);
        Console.WriteLine("File deleted.");

        // Create an instance of the Person class
        Person person = new Person { Name = "Alice Smith", Age = 20 };

        // Serialize the person object to a file
        await SerializeToFileAsync(serializedFilePath, person);

        // Deserialize the person object from the file
        Person deserializedPerson = await DeserializeFromFileAsync(serializedFilePath);

        // Display the deserialized person object
        Console.WriteLine($"Name: {deserializedPerson.Name}, Age: {deserializedPerson.Age}");

        // Clean up serialized file
        File.Delete(serializedFilePath);
        Console.WriteLine("Serialized file deleted.");


        Console.ReadKey();
    }

    // Synchronous methods
    static void WriteToFile(string filePath, string content)
    {
        using (FileStream fs = new FileStream(filePath, FileMode.Create))
        using (StreamWriter writer = new StreamWriter(fs))
        {
            writer.WriteLine(content);
        }
    }

    static string ReadFromFile(string filePath)
    {
        using (FileStream fs = new FileStream(filePath, FileMode.Open))
        using (StreamReader reader = new StreamReader(fs))
        {
            return reader.ReadToEnd();
        }
    }

    // Asynchronous methods
    static async Task WriteToFileAsync(string filePath, string content)
    {
        byte[] encodedText = Encoding.UTF8.GetBytes(content);

        using (FileStream fs = new FileStream(filePath, FileMode.Create, FileAccess.Write, FileShare.None, 4096, true))
        {
            await fs.WriteAsync(encodedText, 0, encodedText.Length);
        }
    }

    static async Task<string> ReadFromFileAsync(string filePath)
    {
        using (FileStream fs = new FileStream(filePath, FileMode.Open, FileAccess.Read, FileShare.None, 4096, true))
        using (StreamReader reader = new StreamReader(fs, Encoding.UTF8))
        {
            return await reader.ReadToEndAsync();
        }
    }

    static async Task SerializeToFileAsync(string filePath, Person person)
    {
        using (FileStream fs = new FileStream(filePath, FileMode.Create))
        {
            await JsonSerializer.SerializeAsync(fs, person);
        }
    }

    static async Task<Person> DeserializeFromFileAsync(string filePath)
    {
        using (FileStream fs = new FileStream(filePath, FileMode.Open))
        {
            return await JsonSerializer.DeserializeAsync<Person>(fs);
        }
    }
}
