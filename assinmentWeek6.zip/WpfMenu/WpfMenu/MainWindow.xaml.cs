﻿using System.Windows;

namespace WpfMenu
{
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
        }

        private void NewMenuItem_Click(object sender, RoutedEventArgs e)
        {
            statusText.Content = "New clicked";
        }

        private void OpenMenuItem_Click(object sender, RoutedEventArgs e)
        {
            statusText.Content = "Open clicked";
        }

        private void SaveMenuItem_Click(object sender, RoutedEventArgs e)
        {
            statusText.Content = "Save clicked";
        }

        private void ExitMenuItem_Click(object sender, RoutedEventArgs e)
        {
            statusText.Content = "Exit clicked";
            Application.Current.Shutdown();
        }

        private void AboutMenuItem_Click(object sender, RoutedEventArgs e)
        {
            statusText.Content = "About clicked";
            MessageBox.Show("This is a WPF application.", "About");
        }
    }
}
